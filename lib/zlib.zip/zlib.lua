/**
 * @upvalue z_stream - Memory for the z_stream.
 * @upvalue remainder - Any remainder from the last deflate call.
 *
 * @param string - "print" to deflate stream.
 * @param int - flush output buffer? Z_SYNC_FLUSH, Z_FULL_FLUSH, or Z_FINISH.
 *
 * if no params, terminates the stream (as if we got empty string and Z_FINISH).
 */
static int lz_filter_impl(
    lua_State *L,
    int (*filter)(z_streamp, int),
    int (*end)(z_streamp), char* name)
{
   z_stream *stream;
   int flush = Z_NO_FLUSH, rc;
   luaL_Buffer buff;
   size_t avail_in;

  if (filter == deflate) {
    const char *const opts[] = { "none", "sync", "full", "finish", NULL };
    flush = luaL_checkoption(L, 2, opts[0], opts);
    if (flush) flush++;
    /* Z_NO_FLUSH(0) Z_SYNC_FLUSH(2), Z_FULL_FLUSH(3), Z_FINISH (4) */

    /* no arguments or nil? terminate the stream */
    if (lua_gettop(L) == 0 || lua_isnil(L, 1)) {
      flush = Z_FINISH;
    }
  }

  stream = (z_stream *)lua_touserdata(L, lua_upvalueindex(1));
  if (stream == NULL) {
    if (lua_gettop(L) >= 1 && lua_isstring(L, 1)) {
      return luaL_error(L, "%s: stream is closed", name);
    }
    lua_pushstring(L, "");
    lua_pushboolean(L, 1);
    return 2;
  }

  luaL_buffinit(L, &buff);

  if (lua_gettop(L) > 1) {
    lua_pushvalue(L, 1);
  }

  if (lua_isstring(L, lua_upvalueindex(2))) {
    lua_pushvalue(L, lua_upvalueindex(2));
    if (lua_gettop(L) > 1 && lua_isstring(L, -2)) {
      lua_concat(L, 2);
    }
  }

  /* perform inflate/deflate */
  stream->next_in = (unsigned char *)lua_tolstring(L, -1, &avail_in);
  stream->avail_in = avail_in;
  if (!stream->avail_in && !flush) {
    /* empty string results in noop */
    lua_pushstring(L, "");
    lua_pushboolean(L, 0);
    lua_pushinteger(L, stream->total_in);
    lua_pushinteger(L, stream->total_out);
    return 4;
  }

  do {
    stream->next_out  = (unsigned char *)luaL_prepbuffer(&buff);
    stream->avail_out = LUAL_BUFFERSIZE;
    rc = filter(stream, flush);
    /* Ignore Z_BUF_ERROR since that just indicates that we
     * need a larger buffer in order to proceed. Thanks to
     * Tobias Markmann for finding this bug!
     */
    if (Z_BUF_ERROR != rc) {
      if (rc != Z_OK && rc != Z_STREAM_END) {
        return luaL_error(L, "%s-ing: %d", name, rc);
      }
    }
    luaL_addsize(&buff, LUAL_BUFFERSIZE - stream->avail_out);
  } while (stream->avail_out == 0);

  /* need to do this before we alter the stack */
  luaL_pushresult(&buff);

  /* save remainder in lua_upvalueindex(2) */
  if (stream->next_in != NULL) {
    lua_pushlstring(L, (char *)stream->next_in, stream->avail_in);
    lua_replace(L, lua_upvalueindex(2));
  }

  /* "close" the stream/remove finalizer */
  if (Z_STREAM_END == rc) {
    /*  Clear-out the metatable so end is not called twice: */
    lua_pushnil(L);
    lua_setmetatable(L, lua_upvalueindex(1));

    /*  nil the upvalue: */
    lua_pushnil(L);
    lua_replace(L, lua_upvalueindex(1));

    /*  Close the stream: */
    rc = end(stream);
    if (rc != Z_OK) {
      return luaL_error(L, "%s: %d", name, rc);
    }

    lua_pushboolean(L, 1);
  } else {
    lua_pushboolean(L, 0);
  }
  lua_pushinteger(L, stream->total_in);
  lua_pushinteger(L, stream->total_out);
  return 4;
}

